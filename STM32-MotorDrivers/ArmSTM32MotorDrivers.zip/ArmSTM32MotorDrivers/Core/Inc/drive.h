// Alex Semenov

#include "stm32f4xx_hal.h"
#include <stdlib.h>

typedef struct newDriver {
	TIM_HandleTypeDef *htim;
	TIM_TypeDef *TIM;
	int timer;
	char *channelManager;
} Driver;

Driver *createDriver(TIM_HandleTypeDef *, int); // (TIM_HandleTypeDef *htim#, int #)
void destroyDriver(Driver *);	// (Driver *driver)
int attachMotor(Driver *,char, int); // (Driver *driver, char identity, int channel)
int pwmTest (Driver *);	// (Driver *driver)
int writeDuty(Driver *, int, float); // (Driver *driver, int channel, float duty)
int servoWrite(Driver *, char, int); // (Driver *driver, char identity, int deg)
int motorWrite(Driver *, char, int); // (Driver *driver, char identity, int power)
int startAll(Driver *);	// (Driver *driver)
int stopAll(Driver *); // (Driver *driver)
int startPWM(Driver *, int); // (Driver *driver, int channel)
int stopPWM(Driver *, int); // (Driver *driver, int channel)
int assignTIM(Driver *); // (Driver *driver)
int getChannel(Driver *, char); // (Driver *driver, char identity)
float mapfloat(float, float, float, float, float); // (float x, float in_min, float in_max, float out_min, float out_max)
int mapInt(int, int, int, int, int); // (int x, int in_min, int in_max, int out_min, int out_max)
